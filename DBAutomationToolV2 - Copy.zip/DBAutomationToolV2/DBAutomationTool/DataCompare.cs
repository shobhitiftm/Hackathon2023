﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;

namespace DBAutomationTool
{
    class DataCompare
    {
        public static DataSet CompareClick(string serverNameString1, string DatabaseNameString1, string TablenameString1, string serverNameString2, string DatabaseNameString2, string TablenameString2)
        {

            SqlConnection con = new SqlConnection();
            string ConnectionString;
            DataSet dtFileDetails = new DataSet();
            try
            {

                ConnectionString = "Data Source=" + serverNameString1 + ";database=Scratch;Integrated Security=true";
                con = new SqlConnection(ConnectionString);
                con.Open();
                SqlCommand sqlCmd = new SqlCommand("CompareData_prc", con);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandTimeout = 120;
                sqlCmd.Parameters.Add("@serverNameString1", SqlDbType.NVarChar).Value = serverNameString1;
                sqlCmd.Parameters.Add("@DatabaseNameString1", SqlDbType.NVarChar).Value = DatabaseNameString1;
                sqlCmd.Parameters.Add("@TablenameString1", SqlDbType.NVarChar).Value = TablenameString1;
                sqlCmd.Parameters.Add("@serverNameString2", SqlDbType.NVarChar).Value = serverNameString2;
                sqlCmd.Parameters.Add("@DatabaseNameString2", SqlDbType.NVarChar).Value = DatabaseNameString2;
                sqlCmd.Parameters.Add("@TablenameString2", SqlDbType.NVarChar).Value = TablenameString2;
                sqlCmd.ExecuteNonQuery();
                SqlDataAdapter sqlDataAdap = new SqlDataAdapter(sqlCmd);
                sqlDataAdap.Fill(dtFileDetails);
                //return dtFileDetails;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
                con.Close();

            }
            return dtFileDetails;




        }

    }
}

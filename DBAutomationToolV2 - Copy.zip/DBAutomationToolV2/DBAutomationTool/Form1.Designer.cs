﻿
namespace DBAutomationTool
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBoxSchema = new System.Windows.Forms.GroupBox();
            this.dataGridViewSchemaTool = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.CheckSchemasButton = new System.Windows.Forms.Button();
            this.Tablename2 = new System.Windows.Forms.ComboBox();
            this.OptionServer2 = new System.Windows.Forms.ComboBox();
            this.OptionDatabase2 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.Tablename1 = new System.Windows.Forms.ComboBox();
            this.OptionDatabase1 = new System.Windows.Forms.ComboBox();
            this.OptionServer1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dataGridViewDC1 = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dataGridViewDC2 = new System.Windows.Forms.DataGridView();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.comboBoxDCTable1 = new System.Windows.Forms.ComboBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.comboBoxDCDB1 = new System.Windows.Forms.ComboBox();
            this.comboBoxDCServer1 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.comboBoxDCTable2 = new System.Windows.Forms.ComboBox();
            this.buttonDC = new System.Windows.Forms.Button();
            this.comboBoxDCServer2 = new System.Windows.Forms.ComboBox();
            this.comboBoxDCDB2 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBoxSchema.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSchemaTool)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDC1)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDC2)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(7, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1384, 787);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBoxSchema);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 34);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1376, 749);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Schema Check";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBoxSchema
            // 
            this.groupBoxSchema.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.groupBoxSchema.Controls.Add(this.dataGridViewSchemaTool);
            this.groupBoxSchema.Location = new System.Drawing.Point(9, 232);
            this.groupBoxSchema.Name = "groupBoxSchema";
            this.groupBoxSchema.Size = new System.Drawing.Size(1308, 369);
            this.groupBoxSchema.TabIndex = 2;
            this.groupBoxSchema.TabStop = false;
            this.groupBoxSchema.Text = "Schema Comparision Results";
            // 
            // dataGridViewSchemaTool
            // 
            this.dataGridViewSchemaTool.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dataGridViewSchemaTool.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSchemaTool.Location = new System.Drawing.Point(6, 29);
            this.dataGridViewSchemaTool.Name = "dataGridViewSchemaTool";
            this.dataGridViewSchemaTool.RowHeadersWidth = 62;
            this.dataGridViewSchemaTool.RowTemplate.Height = 33;
            this.dataGridViewSchemaTool.Size = new System.Drawing.Size(1296, 324);
            this.dataGridViewSchemaTool.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.groupBox2.Controls.Add(this.CheckSchemasButton);
            this.groupBox2.Controls.Add(this.Tablename2);
            this.groupBox2.Controls.Add(this.OptionServer2);
            this.groupBox2.Controls.Add(this.OptionDatabase2);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(553, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(764, 227);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Destination";
            // 
            // CheckSchemasButton
            // 
            this.CheckSchemasButton.Location = new System.Drawing.Point(514, 154);
            this.CheckSchemasButton.Name = "CheckSchemasButton";
            this.CheckSchemasButton.Size = new System.Drawing.Size(112, 34);
            this.CheckSchemasButton.TabIndex = 12;
            this.CheckSchemasButton.Text = "Check";
            this.CheckSchemasButton.UseVisualStyleBackColor = true;
            this.CheckSchemasButton.Click += new System.EventHandler(this.CheckSchemasButton_Click);
            // 
            // Tablename2
            // 
            this.Tablename2.FormattingEnabled = true;
            this.Tablename2.Location = new System.Drawing.Point(153, 154);
            this.Tablename2.Name = "Tablename2";
            this.Tablename2.Size = new System.Drawing.Size(272, 33);
            this.Tablename2.TabIndex = 11;
            // 
            // OptionServer2
            // 
            this.OptionServer2.FormattingEnabled = true;
            this.OptionServer2.Location = new System.Drawing.Point(153, 44);
            this.OptionServer2.Name = "OptionServer2";
            this.OptionServer2.Size = new System.Drawing.Size(272, 33);
            this.OptionServer2.TabIndex = 9;
            this.OptionServer2.SelectedIndexChanged += new System.EventHandler(this.OptionServer2_SelectedIndexChanged);
            // 
            // OptionDatabase2
            // 
            this.OptionDatabase2.FormattingEnabled = true;
            this.OptionDatabase2.Location = new System.Drawing.Point(153, 100);
            this.OptionDatabase2.Name = "OptionDatabase2";
            this.OptionDatabase2.Size = new System.Drawing.Size(272, 33);
            this.OptionDatabase2.TabIndex = 10;
            this.OptionDatabase2.SelectedIndexChanged += new System.EventHandler(this.OptionDatabase2_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(33, 44);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 25);
            this.label6.TabIndex = 6;
            this.label6.Text = "Server";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(33, 100);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(86, 25);
            this.label5.TabIndex = 7;
            this.label5.Text = "Database";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(33, 154);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 25);
            this.label4.TabIndex = 8;
            this.label4.Text = "Table Name";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.Tablename1);
            this.groupBox1.Controls.Add(this.OptionDatabase1);
            this.groupBox1.Controls.Add(this.OptionServer1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(546, 223);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Source";
            // 
            // groupBox3
            // 
            this.groupBox3.Location = new System.Drawing.Point(6, 268);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(300, 150);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "groupBox3";
            // 
            // Tablename1
            // 
            this.Tablename1.FormattingEnabled = true;
            this.Tablename1.Location = new System.Drawing.Point(161, 157);
            this.Tablename1.Name = "Tablename1";
            this.Tablename1.Size = new System.Drawing.Size(272, 33);
            this.Tablename1.TabIndex = 5;
            // 
            // OptionDatabase1
            // 
            this.OptionDatabase1.FormattingEnabled = true;
            this.OptionDatabase1.Location = new System.Drawing.Point(161, 103);
            this.OptionDatabase1.Name = "OptionDatabase1";
            this.OptionDatabase1.Size = new System.Drawing.Size(272, 33);
            this.OptionDatabase1.TabIndex = 4;
            this.OptionDatabase1.SelectedIndexChanged += new System.EventHandler(this.OptionDatabase1_SelectedIndexChanged);
            // 
            // OptionServer1
            // 
            this.OptionServer1.FormattingEnabled = true;
            this.OptionServer1.Location = new System.Drawing.Point(161, 47);
            this.OptionServer1.Name = "OptionServer1";
            this.OptionServer1.Size = new System.Drawing.Size(272, 33);
            this.OptionServer1.TabIndex = 3;
            this.OptionServer1.SelectedIndexChanged += new System.EventHandler(this.OptionServer1_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(41, 157);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Table Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(41, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Database";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(41, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Server";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.tabControl2);
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.groupBox6);
            this.tabPage2.Location = new System.Drawing.Point(4, 34);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1376, 749);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Data Comparision";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Location = new System.Drawing.Point(3, 232);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(1370, 349);
            this.tabControl2.TabIndex = 4;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dataGridViewDC1);
            this.tabPage3.Location = new System.Drawing.Point(4, 34);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1362, 311);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "Match";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dataGridViewDC1
            // 
            this.dataGridViewDC1.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dataGridViewDC1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDC1.Location = new System.Drawing.Point(0, 5);
            this.dataGridViewDC1.Name = "dataGridViewDC1";
            this.dataGridViewDC1.RowHeadersWidth = 62;
            this.dataGridViewDC1.RowTemplate.Height = 33;
            this.dataGridViewDC1.Size = new System.Drawing.Size(1359, 306);
            this.dataGridViewDC1.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.dataGridViewDC2);
            this.tabPage4.Location = new System.Drawing.Point(4, 34);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1362, 311);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "MisMatch";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // dataGridViewDC2
            // 
            this.dataGridViewDC2.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dataGridViewDC2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDC2.Location = new System.Drawing.Point(8, 5);
            this.dataGridViewDC2.Name = "dataGridViewDC2";
            this.dataGridViewDC2.RowHeadersWidth = 62;
            this.dataGridViewDC2.RowTemplate.Height = 33;
            this.dataGridViewDC2.Size = new System.Drawing.Size(1351, 303);
            this.dataGridViewDC2.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.groupBox4.Controls.Add(this.comboBoxDCTable1);
            this.groupBox4.Controls.Add(this.groupBox5);
            this.groupBox4.Controls.Add(this.comboBoxDCDB1);
            this.groupBox4.Controls.Add(this.comboBoxDCServer1);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Location = new System.Drawing.Point(3, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(660, 223);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Source";
            // 
            // comboBoxDCTable1
            // 
            this.comboBoxDCTable1.FormattingEnabled = true;
            this.comboBoxDCTable1.Location = new System.Drawing.Point(161, 157);
            this.comboBoxDCTable1.Name = "comboBoxDCTable1";
            this.comboBoxDCTable1.Size = new System.Drawing.Size(335, 33);
            this.comboBoxDCTable1.TabIndex = 5;
            // 
            // groupBox5
            // 
            this.groupBox5.Location = new System.Drawing.Point(6, 268);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(300, 150);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "groupBox5";
            // 
            // comboBoxDCDB1
            // 
            this.comboBoxDCDB1.FormattingEnabled = true;
            this.comboBoxDCDB1.Location = new System.Drawing.Point(161, 103);
            this.comboBoxDCDB1.Name = "comboBoxDCDB1";
            this.comboBoxDCDB1.Size = new System.Drawing.Size(335, 33);
            this.comboBoxDCDB1.TabIndex = 4;
            this.comboBoxDCDB1.SelectedIndexChanged += new System.EventHandler(this.comboBoxDCDB1_SelectedIndexChanged);
            // 
            // comboBoxDCServer1
            // 
            this.comboBoxDCServer1.FormattingEnabled = true;
            this.comboBoxDCServer1.Location = new System.Drawing.Point(161, 47);
            this.comboBoxDCServer1.Name = "comboBoxDCServer1";
            this.comboBoxDCServer1.Size = new System.Drawing.Size(335, 33);
            this.comboBoxDCServer1.TabIndex = 3;
            this.comboBoxDCServer1.SelectedIndexChanged += new System.EventHandler(this.comboBoxDCServer1_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(41, 157);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(104, 25);
            this.label7.TabIndex = 2;
            this.label7.Text = "Table Name";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(41, 103);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(86, 25);
            this.label8.TabIndex = 1;
            this.label8.Text = "Database";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(41, 47);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(61, 25);
            this.label9.TabIndex = 0;
            this.label9.Text = "Server";
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.groupBox6.Controls.Add(this.comboBoxDCTable2);
            this.groupBox6.Controls.Add(this.buttonDC);
            this.groupBox6.Controls.Add(this.comboBoxDCServer2);
            this.groupBox6.Controls.Add(this.comboBoxDCDB2);
            this.groupBox6.Controls.Add(this.label10);
            this.groupBox6.Controls.Add(this.label11);
            this.groupBox6.Controls.Add(this.label12);
            this.groupBox6.Location = new System.Drawing.Point(669, 3);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(704, 227);
            this.groupBox6.TabIndex = 3;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Destination";
            // 
            // comboBoxDCTable2
            // 
            this.comboBoxDCTable2.FormattingEnabled = true;
            this.comboBoxDCTable2.Location = new System.Drawing.Point(151, 162);
            this.comboBoxDCTable2.Name = "comboBoxDCTable2";
            this.comboBoxDCTable2.Size = new System.Drawing.Size(272, 33);
            this.comboBoxDCTable2.TabIndex = 13;
            // 
            // buttonDC
            // 
            this.buttonDC.Location = new System.Drawing.Point(471, 160);
            this.buttonDC.Name = "buttonDC";
            this.buttonDC.Size = new System.Drawing.Size(136, 34);
            this.buttonDC.TabIndex = 12;
            this.buttonDC.Text = "Compare";
            this.buttonDC.UseVisualStyleBackColor = true;
            this.buttonDC.Click += new System.EventHandler(this.buttonDC_Click);
            // 
            // comboBoxDCServer2
            // 
            this.comboBoxDCServer2.FormattingEnabled = true;
            this.comboBoxDCServer2.Location = new System.Drawing.Point(151, 50);
            this.comboBoxDCServer2.Name = "comboBoxDCServer2";
            this.comboBoxDCServer2.Size = new System.Drawing.Size(272, 33);
            this.comboBoxDCServer2.TabIndex = 9;
            this.comboBoxDCServer2.SelectedIndexChanged += new System.EventHandler(this.comboBoxDCServer2_SelectedIndexChanged);
            // 
            // comboBoxDCDB2
            // 
            this.comboBoxDCDB2.FormattingEnabled = true;
            this.comboBoxDCDB2.Location = new System.Drawing.Point(151, 106);
            this.comboBoxDCDB2.Name = "comboBoxDCDB2";
            this.comboBoxDCDB2.Size = new System.Drawing.Size(272, 33);
            this.comboBoxDCDB2.TabIndex = 10;
            this.comboBoxDCDB2.SelectedIndexChanged += new System.EventHandler(this.comboBoxDCDB2_SelectedIndexChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(31, 50);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(61, 25);
            this.label10.TabIndex = 6;
            this.label10.Text = "Server";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(31, 106);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(86, 25);
            this.label11.TabIndex = 7;
            this.label11.Text = "Database";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(31, 160);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(104, 25);
            this.label12.TabIndex = 8;
            this.label12.Text = "Table Name";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1620, 811);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBoxSchema.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSchemaTool)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDC1)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDC2)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox Tablename2;
        private System.Windows.Forms.ComboBox OptionServer2;
        private System.Windows.Forms.ComboBox OptionDatabase2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox Tablename1;
        private System.Windows.Forms.ComboBox OptionDatabase1;
        private System.Windows.Forms.ComboBox OptionServer1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button CheckSchemasButton;
        private System.Windows.Forms.GroupBox groupBoxSchema;
        private System.Windows.Forms.DataGridView dataGridViewSchemaTool;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBoxDCDB1;
        private System.Windows.Forms.ComboBox comboBoxDCServer1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button buttonDC;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBoxDCTable1;
       
        private System.Windows.Forms.ComboBox comboBoxDCServer2;
        private System.Windows.Forms.ComboBox comboBoxDCDB2;
        private System.Windows.Forms.ComboBox comboBoxDCTable2;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dataGridViewDC1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DataGridView dataGridViewDC2;
    }
}


﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBAutomationTool
{
    public partial class Form1 : Form
    {
        static string comboBoxServerName;
        static string comboBoxDatasetText;
        static string ConnectionString;
        static SqlConnection con;
        static SqlCommand sqlCmd;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadRefData();
        }
        public void LoadRefData()
        {
            //Schema Tool Related
            OptionServer1.Items.Add("DESKTOP-Q17HUNO");
            OptionServer1.Items.Add("PRC02DBSQLTST");
            OptionServer1.Items.Add("PRC03DBSQLTST");
            //OptionServer1.Items.Add("lana\\price");

            OptionServer2.Items.Add("DESKTOP-Q17HUNO");
            OptionServer2.Items.Add("PRC02DBSQLTST");
            OptionServer2.Items.Add("PRC03DBSQLTST");
            //OptionServer2.Items.Add("lana\\price");

            //Data comparision Related
            comboBoxDCServer1.Items.Add("DESKTOP-Q17HUNO");
            comboBoxDCServer1.Items.Add("PRC02DBSQLTST");
            comboBoxDCServer1.Items.Add("PRC03DBSQLTST");
           

            comboBoxDCServer2.Items.Add("DESKTOP-Q17HUNO");
            comboBoxDCServer2.Items.Add("PRC02DBSQLTST");
            comboBoxDCServer2.Items.Add("PRC03DBSQLTST");
           
        }

        private void OptionServer1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBoxServerName = OptionServer1.Text;
            DataTable data = new DataTable();

            if (!String.IsNullOrEmpty(comboBoxServerName))
            {

                Task taskA = Task.Factory.StartNew(() =>
                {
                    data = Methods.filldropdown(comboBoxServerName);
                    if (data != null && data.Rows.Count > 0)
                    {
                        if (OptionDatabase1.InvokeRequired)
                        {
                            OptionDatabase1.Invoke((MethodInvoker)delegate
                            {

                                OptionDatabase1.ValueMember = "name";
                                OptionDatabase1.DisplayMember = "name";
                                OptionDatabase1.DataSource = data;
                              
                            });
                        }
                        else
                        {
                            OptionServer1.Invoke((MethodInvoker)delegate
                            {
                                OptionServer1.Items.Clear();
                            });
                        }
                    }
                });
            }
            else
            {
                MessageBox.Show("Please select the Server");
                OptionServer1.Items.Clear();
            }

        }

        private void OptionDatabase1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
            string serverNameString1 = OptionServer1.Text;
            string DatabaseNameString1 = OptionDatabase1.Text;
            DataTable data = new DataTable();

            if (!String.IsNullOrEmpty(comboBoxServerName))
            {

                Task taskA = Task.Factory.StartNew(() =>
                {
                    data = Methods.filldropdown(serverNameString1, DatabaseNameString1, 2);
                    if (data != null && data.Rows.Count > 0)
                    {
                        if (Tablename1.InvokeRequired)
                        {
                            Tablename1.Invoke((MethodInvoker)delegate
                            {
                                Tablename1.DataSource = data;
                                Tablename1.ValueMember = "table_name";
                                Tablename1.DisplayMember = "table_name";
                               
                            });
                        }
                        else
                        {
                            OptionDatabase1.Invoke((MethodInvoker)delegate
                            {
                                OptionDatabase1.Items.Clear();
                            });
                            OptionServer1.Invoke((MethodInvoker)delegate
                            {
                                OptionServer1.Items.Clear();
                            });
                        }
                    }
                });
            }
            else
            {
                MessageBox.Show("Please select the Server and  Database");
                OptionDatabase1.Items.Clear();
                OptionServer1.Items.Clear();
            }
        }

        private void OptionServer2_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBoxServerName = OptionServer2.Text;
            DataTable data = new DataTable();

            if (!String.IsNullOrEmpty(comboBoxServerName))
            {

                Task taskA = Task.Factory.StartNew(() =>
                {
                    data = Methods.filldropdown(comboBoxServerName);
                    if (data != null && data.Rows.Count > 0)
                    {
                        if (OptionDatabase2.InvokeRequired)
                        {
                            OptionDatabase2.Invoke((MethodInvoker)delegate
                            {
                                OptionDatabase2.ValueMember = "name";
                                OptionDatabase2.DisplayMember = "name";
                                OptionDatabase2.DataSource = data;
                               
                            });
                        }
                        else
                        {
                            OptionServer2.Invoke((MethodInvoker)delegate
                            {
                                OptionServer2.Items.Clear();
                            });
                        }
                    }
                });
            }
            else
            {
                MessageBox.Show("Please select the Server");
                OptionServer2.Items.Clear();
            }
        }

        private void OptionDatabase2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string serverNameString2 = OptionServer2.Text;
            string DatabaseNameString2 = OptionDatabase2.Text;
            DataTable data = new DataTable();
            if (!String.IsNullOrEmpty(comboBoxServerName))
            {

                Task taskA = Task.Factory.StartNew(() =>
                {
                    data = Methods.filldropdown(serverNameString2, DatabaseNameString2, 2);
                    if (data != null && data.Rows.Count > 0)
                    {
                        if (Tablename2.InvokeRequired)
                        {
                            Tablename2.Invoke((MethodInvoker)delegate
                            {
                                Tablename2.DataSource = data;
                                Tablename2.ValueMember = "table_name";
                                Tablename2.DisplayMember = "table_name";
                               
                            });
                        }
                        else
                        {
                            OptionDatabase2.Invoke((MethodInvoker)delegate
                            {
                                OptionDatabase2.Items.Clear();
                            });
                            OptionServer2.Invoke((MethodInvoker)delegate
                            {
                                OptionServer2.Items.Clear();
                            });
                        }
                    }
                });
            }
            else
            {
                MessageBox.Show("Please select the Server and  Database");
                OptionDatabase2.Items.Clear();
                OptionServer2.Items.Clear();
            }
        }

        public DataTable getDataTable(string Servername, string DatabaseNameString, string Tablename)
        {
            ConnectionString = "Data Source=" + Servername + ";database=" + DatabaseNameString + ";Integrated Security=true";
            DataTable dtable_FileTypes = new DataTable();
            try
            {
                con = new SqlConnection(ConnectionString);
                con.Open();
                SqlCommand sqlCmd = new SqlCommand();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.CommandTimeout = 3600;
                sqlCmd.CommandText = "select distinct column_name ,data_type,is_nullable, character_maximum_length FROM information_schema.COLUMNS WHERE table_name='" + Tablename + "'";
                SqlDataAdapter sqlDataAdap = new SqlDataAdapter(sqlCmd);
                sqlDataAdap.Fill(dtable_FileTypes);
                con.Close();
                return dtable_FileTypes;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return dtable_FileTypes;
            }
            finally
            {
                con.Close();
            }
        }

        //Part of Schema Tool
        public ArrayList DataSetToArrayList(int ColumnIndex, DataTable dataTable)
        {
            ArrayList output = new ArrayList();
            foreach (DataRow row in dataTable.Rows)
                output.Add(row[ColumnIndex]);

            return output;
        }
        static Tuple<object, object> GetJoinKey(DataRow row)
        {
            return Tuple.Create(row[0], row[2]);
        }
        private void CheckSchemasButton_Click(object sender, EventArgs e)
        {
            CheckSchemasButton.Enabled = false;
            string TablenameString1 = Tablename1.Text.ToString().ToUpper();
            string TablenameString2 = Tablename2.Text.ToString().ToUpper();

            if (TablenameString1 != "" & TablenameString2 != "")
            {
                string serverNameString1 = OptionServer1.Text;
                string DatabaseNameString1 = OptionDatabase1.Text;
                string serverNameString2 = OptionServer2.Text;
                string DatabaseNameString2 = OptionDatabase2.Text;

                if (TablenameString1 == TablenameString2 && serverNameString1 == serverNameString2 && DatabaseNameString1 == DatabaseNameString2)
                {
                    MessageBox.Show("Smart ! The tables you have selected are the same.");
                }
                else
                {
                    CheckSchemasButton.Enabled = false;
                    DataTable Table1 = null;
                    DataTable Table2 = null;
                    DataTable FinalTable = null;

                    Table1 = getDataTable(serverNameString1, DatabaseNameString1, TablenameString1);
                    Table2 = getDataTable(serverNameString2, DatabaseNameString2, TablenameString2);

                    FinalTable = ext.myJoinMethod(Table1, Table2, GetJoinKey);

                    foreach (var row in FinalTable.AsEnumerable())
                        Console.WriteLine(row[0]);

                    dataGridViewSchemaTool.DataSource = null;
                    dataGridViewSchemaTool.Refresh();

                    dataGridViewSchemaTool.DataSource = FinalTable;
                    dataGridViewSchemaTool.AllowUserToAddRows = false;

                    //Auto sizing the columns !
                    foreach (DataGridViewColumn dcol in dataGridViewSchemaTool.Columns)
                    {
                        dcol.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                    }

                    CheckSchemasButton.Enabled = true;
                }
            }
            else
            {
                MessageBox.Show("Please enter all the fields");
            }
            CheckSchemasButton.Enabled = true;
        }

        private void comboBoxDCServer1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBoxServerName = comboBoxDCServer1.Text;
            DataTable data = new DataTable();

            if (!String.IsNullOrEmpty(comboBoxServerName))
            {

                Task taskA = Task.Factory.StartNew(() =>
                {
                    data = Methods.filldropdown(comboBoxServerName);
                    if (data != null && data.Rows.Count > 0)
                    {
                        if (comboBoxDCDB1.InvokeRequired)
                        {
                            comboBoxDCDB1.Invoke((MethodInvoker)delegate
                            {

                                comboBoxDCDB1.ValueMember = "name";
                                comboBoxDCDB1.DisplayMember = "name";
                                comboBoxDCDB1.DataSource = data;
                               
                            });
                        }
                        else
                        {
                            comboBoxDCServer1.Invoke((MethodInvoker)delegate
                            {
                                comboBoxDCServer1.Items.Clear();
                            });
                        }
                    }
                });
            }
            else
            {
                MessageBox.Show("Please select the Server");
                comboBoxDCServer1.Items.Clear();
            }
        }

        private void comboBoxDCDB1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string serverNameString1 = comboBoxDCServer1.Text;
            string DatabaseNameString1 = comboBoxDCDB1.Text;
            DataTable data = new DataTable();

            if (!String.IsNullOrEmpty(comboBoxServerName))
            {

                Task taskA = Task.Factory.StartNew(() =>
                {
                    data = Methods.filldropdown(serverNameString1, DatabaseNameString1, 2);
                    if (data != null && data.Rows.Count > 0)
                    {
                        if (comboBoxDCTable1.InvokeRequired)
                        {
                            comboBoxDCTable1.Invoke((MethodInvoker)delegate
                            {
                                comboBoxDCTable1.DataSource = data;
                                comboBoxDCTable1.ValueMember = "table_name";
                                comboBoxDCTable1.DisplayMember = "table_name";
                               
                            });
                        }
                        else
                        {
                            comboBoxDCDB1.Invoke((MethodInvoker)delegate
                            {
                                comboBoxDCDB1.Items.Clear();
                            });
                            comboBoxDCServer1.Invoke((MethodInvoker)delegate
                            {
                                comboBoxDCServer1.Items.Clear();
                            });
                        }
                    }
                });
            }
            else
            {
                MessageBox.Show("Please select the Server and  Database");
             
            }
        }

        private void comboBoxDCServer2_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBoxServerName = comboBoxDCServer2.Text;
            DataTable data = new DataTable();

            if (!String.IsNullOrEmpty(comboBoxServerName))
            {

                Task taskA = Task.Factory.StartNew(() =>
                {
                    data = Methods.filldropdown(comboBoxServerName);
                    if (data != null && data.Rows.Count > 0)
                    {
                        if (comboBoxDCDB2.InvokeRequired)
                        {
                            comboBoxDCDB2.Invoke((MethodInvoker)delegate
                            {

                                comboBoxDCDB2.ValueMember = "name";
                                comboBoxDCDB2.DisplayMember = "name";
                                comboBoxDCDB2.DataSource = data;
                               
                            });
                        }
                        else
                        {
                            comboBoxDCServer2.Invoke((MethodInvoker)delegate
                            {
                                comboBoxDCServer2.Items.Clear();
                            });
                        }
                    }
                });
            }
            else
            {
                MessageBox.Show("Please select the Server");
                comboBoxDCServer2.Items.Clear();
            }
        }

        private void comboBoxDCDB2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string serverNameString1 = comboBoxDCServer2.Text;
            string DatabaseNameString1 = comboBoxDCDB2.Text;
            DataTable data = new DataTable();

            if (!String.IsNullOrEmpty(comboBoxServerName))
            {

                Task taskA = Task.Factory.StartNew(() =>
                {
                    data = Methods.filldropdown(serverNameString1, DatabaseNameString1, 2);
                    if (data != null && data.Rows.Count > 0)
                    {
                        if (comboBoxDCTable2.InvokeRequired)
                        {
                            comboBoxDCTable2.Invoke((MethodInvoker)delegate
                            {
                                comboBoxDCTable2.DataSource = data;
                                comboBoxDCTable2.ValueMember = "table_name";
                                comboBoxDCTable2.DisplayMember = "table_name";
                               
                            });
                        }
                        else
                        {
                            comboBoxDCDB2.Invoke((MethodInvoker)delegate
                            {
                                comboBoxDCDB2.Items.Clear();
                            });
                            comboBoxDCServer2.Invoke((MethodInvoker)delegate
                            {
                                comboBoxDCServer2.Items.Clear();
                            });
                        }
                    }
                });
            }
            else
            {
                MessageBox.Show("Please select the Server and  Database");
               
            }
        }

        private void buttonDC_Click(object sender, EventArgs e)
        {
            buttonDC.Enabled = false;
           
            string TablenameString1 = comboBoxDCTable1.Text.ToString().ToUpper();
            string TablenameString2 = comboBoxDCTable2.Text.ToString().ToUpper();
            DataSet data = new DataSet();
            if (TablenameString1 != "" & TablenameString2 != "")
            {
                string serverNameString1 = comboBoxDCServer1.Text;
                string DatabaseNameString1 = comboBoxDCDB1.Text;
                string serverNameString2 = comboBoxDCServer2.Text;
                string DatabaseNameString2 = comboBoxDCDB2.Text;

                if (TablenameString1 == TablenameString2 && serverNameString1 == serverNameString2 && DatabaseNameString1 == DatabaseNameString2)
                {
                    MessageBox.Show("Smart ! The tables you have selected are the same.");
                  
                }
                else
                {
                    buttonDC.Enabled = false;
                    Task taskA = Task.Factory.StartNew(() =>
                    {
                        data = DataCompare.CompareClick(serverNameString1, DatabaseNameString1, TablenameString1, serverNameString2, DatabaseNameString2, TablenameString2);
                        if (data != null && data.Tables.Count > 0)
                        {
                            if (comboBoxDCTable2.InvokeRequired)
                            {
                                comboBoxDCTable2.Invoke((MethodInvoker)delegate
                                {

                                    dataGridViewDC1.DataSource = data.Tables[0];
                                   
                                });
                            }
                            else
                            {
                                comboBoxDCTable2.Invoke((MethodInvoker)delegate
                                {
                                    comboBoxDCTable2.Items.Clear();
                                });
                                comboBoxDCServer1.Invoke((MethodInvoker)delegate
                                {
                                    comboBoxDCServer1.Items.Clear();
                                    
                                });
                            }
                        }
                    });
                    buttonDC.Enabled = true;
                }
            }
            else
            {
                MessageBox.Show("Please enter all the fields");
               
            }
            buttonDC.Enabled = true;
        }
    }

    public static class ext
    {
        public static DataTable myJoinMethod<T>(this DataTable table1, DataTable table2, Func<DataRow, T> keygen)
        {
            DataTable result = new DataTable();
            if (table1 != null && table2 != null)
            {
                var row1def = new object[table1.Columns.Count];
                var row2def = new object[table2.Columns.Count];

                // perform inital outer join operation
                var outerjoin =
                    (
                        from row1 in table1.AsEnumerable()
                        join row2 in table2.AsEnumerable()
                            on keygen(row1) equals keygen(row2)
                            into matches
                        from row2 in matches.DefaultIfEmpty()
                        select new { key = keygen(row1), row1, row2 }
                    ).Union(
                        from row2 in table2.AsEnumerable()
                        join row1 in table1.AsEnumerable()
                            on keygen(row2) equals keygen(row1)
                            into matches
                        from row1 in matches.DefaultIfEmpty()
                        select new { key = keygen(row2), row1, row2 }
                    ).Select(r => new
                    {
                        //r.key,
                        row1 = (r.row1 == null ? row1def : r.row1.ItemArray),
                        row2 = (r.row2 == null ? row2def : r.row2.ItemArray)
                    }).Select(r =>
                        new object[] { //r.key.ToString() 
                        }
                        .Concat(r.row1)
                        .Concat(r.row2)
                        .ToArray()
                    );

                // Create result table

                // result.Columns.Add("__key", typeof(string));
                foreach (var col in table1.Columns.OfType<DataColumn>())
                    result.Columns.Add("T1_" + col.ColumnName, col.DataType);
                foreach (var col in table2.Columns.OfType<DataColumn>())
                    result.Columns.Add("T2_" + col.ColumnName, col.DataType);

                // fill table from join query
                foreach (var src in outerjoin)
                    result.Rows.Add(src);


            }
            return result;
        }

    }
}

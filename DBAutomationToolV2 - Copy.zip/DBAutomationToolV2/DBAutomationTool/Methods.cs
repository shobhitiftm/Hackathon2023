﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;

namespace DBAutomationTool
{
    class Methods
    {
        public static bool ValidFile(string fname)
        {
            if (System.IO.File.Exists(fname))
                return true;
            else
                return false;
        }

        public static DataTable filldropdown(string comboBoxServerName, string text, int mode)
        {
            SqlConnection con;
            string ConnectionString;
            DataTable dtable_FileTypes = new DataTable();


            if (mode == 1)
            {
                int FileTypeFormat = 0;
                if (!String.IsNullOrEmpty(comboBoxServerName))
                {
                    ConnectionString = "Data Source=" + comboBoxServerName + ";database=Scratch;Integrated Security=true";
                    con = new SqlConnection(ConnectionString);
                    switch (text)
                    {
                        case "EOD":
                            FileTypeFormat = 35;
                            break;
                        case "MFDSCA":
                            FileTypeFormat = 36;
                            break;
                        case "MFDSP":
                            FileTypeFormat = 37;
                            break;
                        case "Futures":
                            FileTypeFormat = 38;
                            break;
                    }
                    try
                    {


                        con.Open();
                        SqlCommand sqlCmd = new SqlCommand("GetFileTypes_prc", con);
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.Parameters.Add("@fileTypeFormatId", SqlDbType.Int);
                        sqlCmd.Parameters["@fileTypeFormatId"].Value = FileTypeFormat;
                        sqlCmd.ExecuteNonQuery();
                        SqlDataAdapter sqlDataAdap = new SqlDataAdapter(sqlCmd);
                        sqlDataAdap.Fill(dtable_FileTypes);

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            else if (mode == 2)
            {
                if (!String.IsNullOrEmpty(comboBoxServerName))
                {
                    ConnectionString = "Data Source=" + comboBoxServerName + ";database=" + text + ";Integrated Security=true";
                    con = new SqlConnection(ConnectionString);
                    try
                    {
                        con.Open();
                        SqlCommand sqlCmd = new SqlCommand();
                        sqlCmd.Connection = con;
                        sqlCmd.CommandTimeout = 3600;
                        sqlCmd.CommandType = CommandType.Text;
                        sqlCmd.CommandText = "Select table_name from information_schema.tables order by table_name asc";
                        SqlDataAdapter sqlDataAdap = new SqlDataAdapter(sqlCmd);
                        sqlDataAdap.Fill(dtable_FileTypes);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            return dtable_FileTypes;
        }


        public static DataTable filldropdown(string comboBoxServerName)
        {
            SqlConnection con;
            string ConnectionString;
            DataTable dtable_FileTypes = new DataTable();
            if (!String.IsNullOrEmpty(comboBoxServerName))
            {
                ConnectionString = "Data Source=" + comboBoxServerName + ";database=FlinnIdentityUserDB;Integrated Security=true";
                con = new SqlConnection(ConnectionString);
                try
                {
                    con = new SqlConnection(ConnectionString);
                    con.Open();
                    SqlCommand sqlCmd = new SqlCommand();
                    sqlCmd.Connection = con;
                    sqlCmd.CommandType = CommandType.Text;
                    sqlCmd.CommandText = "SELECT name FROM sys.databases order by name";
                    SqlDataAdapter sqlDataAdap = new SqlDataAdapter(sqlCmd);
                    sqlDataAdap.Fill(dtable_FileTypes);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
                finally
                {
                    con.Close();

                }
            }
            return dtable_FileTypes;
        }
    }
}
